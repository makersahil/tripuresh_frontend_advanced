import { ReactNode, useEffect } from "react";

type ModalProps = {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
  footer?: ReactNode; // actions row (Save/Cancel)
  size?: "sm" | "md" | "lg" | "xl";
  preventCloseOnBackdrop?: boolean;
};

const sizeMap: Record<NonNullable<ModalProps["size"]>, string> = {
  sm: "max-w-md",
  md: "max-w-lg",
  lg: "max-w-2xl",
  xl: "max-w-4xl",
};

export default function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  size = "md",
  preventCloseOnBackdrop,
}: ModalProps) {
  // ESC to close
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      aria-modal="true"
      role="dialog"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center"
    >
      <div
        className="absolute inset-0 bg-black/40"
        onClick={() => !preventCloseOnBackdrop && onClose()}
      />
      <div className={`relative z-10 w-full ${sizeMap[size]} mx-auto`}>
        <div className="rounded-2xl bg-white shadow-xl overflow-hidden">
          {title && (
            <div className="px-5 py-4 border-b">
              <h3 className="text-lg font-semibold">{title}</h3>
            </div>
          )}
          <div className="px-5 py-4">{children}</div>
          {footer && <div className="px-5 py-3 border-t bg-gray-50">{footer}</div>}
        </div>
      </div>
    </div>
  );
}
