import { useEffect, useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import Modal from "@/admin/common/Modal";
import ArticleForm from "./ArticleForm";
import { adminListArticles, adminCreateArticle, adminUpdateArticle, adminDeleteArticle, type PageMeta } from "./api";
import type { Article } from "./schema";

export default function AdminArticlesPage() {
  const [items, setItems] = useState<Article[]>([]);
  const [meta, setMeta] = useState<PageMeta>({ page: 1, pageSize: 10, total: 0, pages: 1 });
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  const [flash, setFlash] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // modal state
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Article | null>(null);

  const params = useMemo(() => ({ page: meta.page, pageSize: meta.pageSize, q }), [meta.page, meta.pageSize, q]);

  async function load() {
    setLoading(true); setError(null);
    try {
      const { items, meta } = await adminListArticles(params);
      setItems(items); setMeta(meta);
    } catch (e: any) {
      setError(e?.message || "Failed to load articles");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [params.page, params.pageSize, params.q]);

  function openCreate() {
    setEditing(null);
    setOpen(true);
  }
  function openEdit(it: Article) {
    setEditing(it);
    setOpen(true);
  }

  async function handleCreate(values: any) {
    await adminCreateArticle(values);
    setOpen(false); setFlash("Article created");
    await load();
  }
  async function handleUpdate(values: any) {
    if (!editing?.id) return;
    await adminUpdateArticle(editing.id, values);
    setOpen(false); setFlash("Article updated");
    await load();
  }
  async function handleDelete(it: Article) {
    if (!confirm(`Delete "${it.title}"? This cannot be undone.`)) return;
    await adminDeleteArticle(it.id);
    setFlash("Article deleted");
    await load();
  }

  return (
    <section className="p-4 md:p-6">
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-xl font-bold">Articles</h1>
        <div className="flex gap-2">
          <Input placeholder="Search…" value={q} onChange={(e)=>setQ(e.target.value)} />
          <Button onClick={openCreate}>New</Button>
        </div>
      </div>

      {flash && <div className="mb-3 rounded-xl border border-green-300 bg-green-50 p-2 text-green-800 text-sm">{flash}</div>}
      {error && <div className="mb-3 rounded-xl border border-red-300 bg-red-50 p-2 text-red-800 text-sm">{error}</div>}

      <div className="overflow-x-auto rounded-2xl border">
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-2 font-semibold">Title</th>
              <th className="px-4 py-2 font-semibold">Slug</th>
              <th className="px-4 py-2 font-semibold">Status</th>
              <th className="px-4 py-2 font-semibold">Updated</th>
              <th className="px-4 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td className="px-4 py-6" colSpan={5}>Loading…</td></tr>
            )}
            {!loading && items.length === 0 && (
              <tr><td className="px-4 py-6 text-gray-500" colSpan={5}>No results</td></tr>
            )}
            {items.map(it => (
              <tr key={it.id} className="border-t">
                <td className="px-4 py-2">{it.title}</td>
                <td className="px-4 py-2 text-gray-600">{it.slug}</td>
                <td className="px-4 py-2">
                  <span className={`rounded-full px-2 py-0.5 text-xs ${it.status === "published" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-700"}`}>
                    {it.status || "draft"}
                  </span>
                </td>
                <td className="px-4 py-2 text-gray-600">{(it as any).updatedAt?.slice(0,10) || ""}</td>
                <td className="px-4 py-2 text-right">
                  <div className="flex justify-end gap-2">
                    <Button variant="secondary" onClick={()=>openEdit(it)}>Edit</Button>
                    <Button variant="destructive" onClick={()=>handleDelete(it)}>Delete</Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* pagination */}
      <div className="mt-4 flex items-center justify-end gap-2 text-sm">
        <span>Page {meta.page} / {meta.pages} · {meta.total} total</span>
        <Button variant="secondary" disabled={meta.page <= 1} onClick={()=>setMeta(m=>({ ...m, page: m.page-1 }))}>Prev</Button>
        <Button variant="secondary" disabled={meta.page >= meta.pages} onClick={()=>setMeta(m=>({ ...m, page: m.page+1 }))}>Next</Button>
      </div>

      <Modal open={open} onClose={()=>setOpen(false)} title={editing ? "Edit Article" : "New Article"} widthClass="max-w-2xl">
        <ArticleForm
          initial={editing || undefined}
          onSubmit={editing ? handleUpdate : handleCreate}
          submitLabel={editing ? "Update" : "Create"}
        />
      </Modal>
    </section>
  );
}
