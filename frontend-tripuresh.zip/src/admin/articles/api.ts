import { http } from "@/config/api";
import type { ArticleInput, Article } from "./schema";

export type PageMeta = { page: number; pageSize: number; total: number; pages: number; };

export async function adminListArticles(params: { page?: number; pageSize?: number; q?: string; }) {
  const res = await http.get("/articles", { params });
  // envelope: { success, data, meta }
  const items: Article[] = (res.data?.data ?? []) as Article[];
  const meta: PageMeta = res.data?.meta ?? { page: 1, pageSize: items.length, total: items.length, pages: 1 };
  return { items, meta };
}

export async function adminGetArticle(id: string) {
  const res = await http.get(`/articles/${id}`);
  return res.data?.data as Article;
}

export async function adminCreateArticle(input: ArticleInput) {
  const res = await http.post("/api/v1/admin/articles", input);
  return res.data?.data as Article;
}

export async function adminUpdateArticle(id: string, input: ArticleInput) {
  const res = await http.put(`/api/v1/admin/articles/${id}`, input);
  return res.data?.data as Article;
}

export async function adminDeleteArticle(id: string) {
  await http.delete(`/api/v1/admin/articles/${id}`);
}
