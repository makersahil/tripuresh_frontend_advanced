import { useState } from "react";
import { z } from "zod";
import { ArticleSchema, type ArticleInput } from "./schema";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

type Props = {
  initial?: Partial<ArticleInput>;
  onSubmit: (values: ArticleInput) => Promise<void>;
  submitLabel?: string;
};

export default function ArticleForm({ initial, onSubmit, submitLabel = "Save" }: Props) {
  const [values, setValues] = useState<ArticleInput>({
    title: "",
    slug: "",
    summary: "",
    status: "draft",
    publishedAt: "",
    externalUrl: "",
    ...initial,
  } as ArticleInput);
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  function set<K extends keyof ArticleInput>(k: K, v: ArticleInput[K]) {
    setValues((s) => ({ ...s, [k]: v }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null); setOk(null);
    try {
      const parsed = ArticleSchema.parse(values);
      setSaving(true);
      await onSubmit(parsed);
      setOk("Saved successfully");
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        setError(err.issues[0]?.message || "Please check your inputs");
      } else {
        setError(err?.message || "Failed to save");
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <form className="grid gap-3" onSubmit={handleSubmit}>
      <label className="grid gap-1">
        <span className="text-sm font-medium">Title</span>
        <Input value={values.title} onChange={(e)=>set("title", e.target.value)} required />
      </label>

      <label className="grid gap-1">
        <span className="text-sm font-medium">Slug</span>
        <Input value={values.slug} onChange={(e)=>set("slug", e.target.value)} required />
      </label>

      <label className="grid gap-1">
        <span className="text-sm font-medium">Summary</span>
        <textarea
          className="rounded-2xl border px-3 py-2"
          rows={3}
          value={values.summary || ""}
          onChange={(e)=>set("summary", e.target.value)}
        />
      </label>

      <div className="grid grid-cols-2 gap-3">
        <label className="grid gap-1">
          <span className="text-sm font-medium">Status</span>
          <select className="rounded-2xl border px-3 py-2" value={values.status} onChange={(e)=>set("status", e.target.value as any)}>
            <option value="draft">Draft</option>
            <option value="published">Published</option>
          </select>
        </label>
        <label className="grid gap-1">
          <span className="text-sm font-medium">Published At (ISO)</span>
          <Input value={values.publishedAt || ""} onChange={(e)=>set("publishedAt", e.target.value)} placeholder="2025-08-17T10:00:00Z" />
        </label>
      </div>

      <label className="grid gap-1">
        <span className="text-sm font-medium">External URL</span>
        <Input value={values.externalUrl || ""} onChange={(e)=>set("externalUrl", e.target.value)} placeholder="https://..." />
      </label>

      {error && <div className="rounded-xl border border-red-300 bg-red-50 p-2 text-red-800 text-sm">{error}</div>}
      {ok && <div className="rounded-xl border border-green-300 bg-green-50 p-2 text-green-800 text-sm">{ok}</div>}

      <div className="flex items-center gap-2">
        <Button type="submit" disabled={saving}>{saving ? "Saving…" : submitLabel}</Button>
      </div>
    </form>
  );
}
