import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate, useParams, useSearchParams } from "react-router-dom";
import ArticleForm from "./ArticleForm";
import { updateArticle } from "./adminApi";
import type { ArticleInput } from "./adminApi";
import { http } from "@/config/api";

// tiny helpers
function isUuidLike(s: string) {
  // loose check: 8-4-4-4-12, case-insensitive; good enough to decide id vs slug
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
}

type PublicArticle = {
  id: string;
  title: string;
  abstract?: string | null;
  journal: string;
  year: number;
  doi?: string | null;
  link?: string | null;
  slug: string;
  tags?: string[] | null;
  legacyAuthors?: string | null;
  published?: boolean;
  // backend may return authors in different shapes; we handle a few:
  authors?:
    | Array<{ firstName?: string; lastName?: string; fullName?: string }>
    | Array<string>;
};

export default function AdminArticleEditPage() {
  const nav = useNavigate();
  const params = useParams<{ id?: string; slug?: string }>();
  const [sp] = useSearchParams();
  const loc = useLocation() as any;

  const [busy, setBusy] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [initial, setInitial] = useState<ArticleInput | null>(null);
  const [articleId, setArticleId] = useState<string | null>(null); // needed for PUT

  // Resolve identifier in this order:
  // 1) state.record from list (fastest, no fetch needed for mapping base fields)
  // 2) query ?slug=...
  // 3) :slug param
  // 4) :id param (UUID-like → try admin detail; otherwise treat as slug)
  const identifier = useMemo(() => {
    if (loc?.state?.record) return loc.state.record.slug as string;
    if (sp.get("slug")) return sp.get("slug")!;
    if (params.slug) return params.slug;
    if (params.id && !isUuidLike(params.id)) return params.id; // treat as slug
    return null;
  }, [loc?.state, sp, params.slug, params.id]);

  // Best-effort loader. We first try:
  // - If we have state.record, map immediately and then (in background) refresh from server.
  // - Else if we have a slug → GET /articles/:slug (public)
  // - Else if we have an id (UUID) → try GET /api/v1/admin/articles/:id (if available)
  useEffect(() => {
    let alive = true;

    async function mapPublicToForm(a: PublicArticle): Promise<ArticleInput> {
      // Normalize authors to authorsList: {firstName,lastName}[]
      const authorsList: { firstName: string; lastName: string }[] = [];

      if (Array.isArray(a.authors)) {
        a.authors.forEach((entry: any) => {
          if (typeof entry === "string") {
            const parts = entry.trim().split(/\s+/);
            const lastName = parts.pop() || "";
            const firstName = parts.join(" ");
            if (firstName || lastName) authorsList.push({ firstName, lastName });
          } else if (entry && (entry.firstName || entry.lastName)) {
            authorsList.push({
              firstName: (entry.firstName || "").trim(),
              lastName: (entry.lastName || "").trim(),
            });
          } else if (entry?.fullName) {
            const parts = String(entry.fullName).trim().split(/\s+/);
            const lastName = parts.pop() || "";
            const firstName = parts.join(" ");
            authorsList.push({ firstName, lastName });
          }
        });
      }

      return {
        title: a.title,
        abstract: a.abstract ?? "",
        journal: a.journal,
        year: a.year,
        doi: a.doi ?? "",
        link: a.link ?? "",
        tags: Array.isArray(a.tags) ? a.tags : [],
        legacyAuthors: a.legacyAuthors ?? "",
        published: typeof a.published === "boolean" ? a.published : true,
        authorsList,
      };
    }

    async function load() {
      try {
        setBusy(true);
        setErr(null);

        // Case A: we were navigated with a record in router state (from list)
        if (loc?.state?.record) {
          const r = loc.state.record as PublicArticle;
          setArticleId(r.id);
          const mapped = await mapPublicToForm(r);
          if (!alive) return;
          setInitial(mapped);
          setBusy(false);

          // Optional: background refresh from server by slug if we can
          if (r.slug) {
            try {
              const { data } = await http.get(`/articles/${encodeURIComponent(r.slug)}`);
              if (!alive) return;
              const fresh = await mapPublicToForm(data as PublicArticle);
              setInitial(fresh);
              setArticleId((data as any)?.id || r.id);
            } catch {
              /* ignore background refresh failure */
            }
          }
          return;
        }

        // Case B: we have a slug (preferred)
        if (identifier) {
          const { data } = await http.get(`/articles/${encodeURIComponent(identifier)}`);
          const a = data as PublicArticle;
          if (!alive) return;
          setArticleId(a.id);
          setInitial(await mapPublicToForm(a));
          setBusy(false);
          return;
        }

        // Case C: we only have a UUID-like id → try admin detail (if backend supports it)
        if (params.id && isUuidLike(params.id)) {
          // Not documented, but some backends expose this. If 404, show error.
          const { data } = await http.get(`/api/v1/admin/articles/${params.id}`);
          const a = data as PublicArticle;
          if (!alive) return;
          setArticleId(a.id);
          setInitial(await mapPublicToForm(a));
          setBusy(false);
          return;
        }

        throw new Error("No slug or id provided for article edit.");
      } catch (e: any) {
        if (!alive) return;
        setErr(e?.message || "Failed to load article.");
        setBusy(false);
      }
    }

    load();
    return () => {
      alive = false;
    };
  }, [identifier, loc?.state, params.id]);

  async function handleSave(payload: ArticleInput) {
    if (!articleId) {
      setErr("Missing article id to update.");
      return;
    }
    await updateArticle(articleId, payload);
    nav("/admin/articles", { replace: true });
  }

  if (busy) {
    return (
      <section className="container py-8">
        <div className="text-sm text-muted-foreground">Loading article…</div>
      </section>
    );
  }

  if (err) {
    return (
      <section className="container py-8">
        <h1 className="text-xl font-semibold mb-2">Edit Article</h1>
        <div className="rounded-xl border border-red-300 bg-red-50 p-3 text-sm text-red-800">
          {err}
        </div>
      </section>
    );
  }

  if (!initial) {
    return (
      <section className="container py-8">
        <h1 className="text-xl font-semibold mb-2">Edit Article</h1>
        <div className="text-sm text-muted-foreground">Nothing to edit.</div>
      </section>
    );
  }

  return (
    <section className="container py-8">
      <div className="mb-5">
        <h1 className="text-xl font-semibold">Edit Article</h1>
        <p className="text-sm text-muted-foreground">
          Update research article fields and authors.
        </p>
      </div>
      <ArticleForm
        initialValues={initial}
        onSave={handleSave}
        onCancel={() => nav("/admin/articles")}
      />
    </section>
  );
}
