import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getOk, http } from "@/config/api";
import type { Article } from "@/lib/types";
import TagsInput from "@/components/shared/TagChips";
import AuthorsManager from "./AuthorsManager";
import { useAuth } from "@/features/auth/useAuth";
import InlineAlert from "@/components/feedback/InlineAlert"; // if you have one, else simple div

type SimpleAuthor = { firstName: string; lastName: string };
export default function AdminArticleEditPage({ mode = "create" as "create" | "edit" }) {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { token } = useAuth();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  // form state
  const [title, setTitle] = useState("");
  const [journal, setJournal] = useState("");
  const [year, setYear] = useState<number | "">("");
  const [abstract, setAbstract] = useState("");
  const [doi, setDoi] = useState("");
  const [link, setLink] = useState("");
  const [legacyAuthors, setLegacyAuthors] = useState("");
  const [published, setPublished] = useState(true);
  const [tags, setTags] = useState<string[]>([]);
  const [authors, setAuthors] = useState<SimpleAuthor[]>([]);

  const isEdit = mode === "edit";

  // Prefill when editing
  useEffect(() => {
    let active = true;
    (async () => {
      if (!isEdit || !slug) return;
      try {
        setBusy(true);
        const res = await getOk<Article>(`/articles/${slug}`);
        const a = res.data as any;
        if (!active) return;
        setTitle(a.title ?? "");
        setJournal(a.journal ?? "");
        setYear(a.year ?? "");
        setAbstract(a.abstract ?? "");
        setDoi(a.doi ?? "");
        setLink(a.link ?? "");
        setLegacyAuthors(a.legacyAuthors ?? "");
        setPublished(a.published ?? true);
        setTags(Array.isArray(a.tags) ? a.tags : []);
        // map authors: either embedded as join rows or flat; normalize to [{firstName,lastName}]
        const normAuthors: SimpleAuthor[] =
          Array.isArray(a.authors)
            ? a.authors
                .sort((x: any, y: any) => (x.position ?? 0) - (y.position ?? 0))
                .map((row: any) => {
                  if (row?.author) return { firstName: row.author.firstName, lastName: row.author.lastName };
                  return { firstName: row.firstName, lastName: row.lastName };
                })
            : [];
        setAuthors(normAuthors);
      } catch (e: any) {
        setErr(e?.message || "Failed to load article");
      } finally {
        setBusy(false);
      }
    })();
    return () => { active = false; };
  }, [isEdit, slug]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    try {
      setBusy(true);

      const payload: any = {
        title,
        journal,
        year: typeof year === "string" ? parseInt(year || "0", 10) : year,
        abstract: abstract || undefined,
        doi: doi || undefined,
        link: link || undefined,
        legacyAuthors: legacyAuthors || undefined,
        tags,
        published
      };
      // authorsList → only if there are entries
      if (authors.length > 0) {
        payload.authorsList = authors.map((a) => ({ firstName: a.firstName.trim(), lastName: a.lastName.trim() }));
      }

      if (isEdit && slug) {
        // We don’t have admin GET, but admin PUT **does** exist (by id in docs),
        // Your backend also accepts PUT by id. Since we only have slug here,
        // add a tiny step: fetch article by slug → get id → PUT /admin/articles/:id
        const { data: existing } = await getOk<any>(`/articles/${slug}`);
        await http.put(`/api/v1/admin/articles/${existing.id}`, payload, {
          headers: { Authorization: `Bearer ${token}` },
        });
      } else {
        await http.post(`/api/v1/admin/articles`, payload, {
          headers: { Authorization: `Bearer ${token}` },
        });
      }

      navigate("/admin/articles", { replace: true });
    } catch (e: any) {
      setErr(e?.response?.data?.message || e?.message || "Save failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="container py-6">
      <h1 className="text-2xl font-semibold mb-4">{isEdit ? "Edit Article" : "New Article"}</h1>
      {err && <div className="rounded-xl border border-red-300 bg-red-50 p-2 text-sm text-red-700">{err}</div>}
      <form onSubmit={onSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main column */}
        <div className="lg:col-span-2 grid gap-4">
          <label className="grid gap-1">
            <span className="text-sm font-medium">Title *</span>
            <input className="rounded-xl border px-3 py-2" value={title} onChange={e => setTitle(e.target.value)} required />
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <label className="grid gap-1">
              <span className="text-sm font-medium">Journal *</span>
              <input className="rounded-xl border px-3 py-2" value={journal} onChange={e => setJournal(e.target.value)} required />
            </label>
            <label className="grid gap-1">
              <span className="text-sm font-medium">Year *</span>
              <input type="number" className="rounded-xl border px-3 py-2" value={year} onChange={e => setYear(e.target.value ? parseInt(e.target.value, 10) : "")} required />
            </label>
            <label className="grid gap-1">
              <span className="text-sm font-medium">Published</span>
              <input type="checkbox" checked={published} onChange={e => setPublished(e.target.checked)} />
            </label>
          </div>
          <label className="grid gap-1">
            <span className="text-sm font-medium">Abstract</span>
            <textarea className="rounded-xl border px-3 py-2 min-h-28" value={abstract} onChange={e => setAbstract(e.target.value)} />
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <label className="grid gap-1">
              <span className="text-sm font-medium">DOI (full URL or id)</span>
              <input className="rounded-xl border px-3 py-2" value={doi} onChange={e => setDoi(e.target.value)} />
            </label>
            <label className="grid gap-1">
              <span className="text-sm font-medium">Link (full URL)</span>
              <input className="rounded-xl border px-3 py-2" value={link} onChange={e => setLink(e.target.value)} />
            </label>
          </div>
          <label className="grid gap-1">
            <span className="text-sm font-medium">Tags</span>
            <TagsInput value={tags} onChange={setTags} />
          </label>
          <label className="grid gap-1">
            <span className="text-sm font-medium">Legacy authors (note)</span>
            <input className="rounded-xl border px-3 py-2" value={legacyAuthors} onChange={e => setLegacyAuthors(e.target.value)} />
          </label>
          <div className="flex gap-2">
            <button disabled={busy} className="rounded-2xl px-4 py-2 bg-primary text-white disabled:opacity-50">
              {busy ? "Saving…" : "Save"}
            </button>
            <button type="button" onClick={() => navigate(-1)} className="rounded-2xl px-4 py-2 border">
              Cancel
            </button>
          </div>
        </div>
        {/* Right rail: authors */}
        <aside className="lg:col-span-1">
          <AuthorsManager value={authors} onChange={setAuthors} />
        </aside>
      </form>
    </section>
  );
}
